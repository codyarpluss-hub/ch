package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.BuildConfig
import com.example.data.db.CustomErrorEntity
import com.example.data.db.SavedErrorEntity
import com.example.data.model.*
import com.example.ui.AssistantViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts

// Custom Theme Colors matching Codyar HTML
val CodyarNavy = Color(0xFF1C2B4A)
val CodyarRed = Color(0xFFE0393E)
val CodyarBg = Color(0xFFF7F8FA)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AssistantScreen(
    viewModel: AssistantViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = results?.firstOrNull() ?: ""
            if (spokenText.isNotEmpty()) {
                viewModel.updateSearchFilters(spokenText, viewModel.selectedBrand.value, viewModel.selectedCategory.value)
            }
        }
    }

    // Screen navigation state
    // "home", "search", "problems", "store", "profile", "technicians", "orders", "ai_chat"
    var activeTab by remember { mutableStateOf("home") }

    // Dialog & Sheet states
    var showAuthDialog by remember { mutableStateOf(false) }
    var authMode by remember { mutableStateOf("login") } // "login" or "register"

    var showCartDialog by remember { mutableStateOf(false) }
    var cartStep by remember { mutableStateOf("cart") } // "cart" or "payment"

    var showPlansDialog by remember { mutableStateOf(false) }
    var showPayDialog by remember { mutableStateOf(false) }
    var selectedPlanForPay by remember { mutableStateOf<Map<String, Any>?>(null) }

    // Detail view states
    var selectedErrorDetail by remember { mutableStateOf<KodyarErrorCode?>(null) }
    var selectedProblemDetail by remember { mutableStateOf<KodyarCommonProblem?>(null) }

    // Form inputs
    var authPhone by remember { mutableStateOf("") }
    var authPassword by remember { mutableStateOf("") }
    var authName by remember { mutableStateOf("") }
    var authRole by remember { mutableStateOf("customer") } // "customer" or "technician"
    var authCity by remember { mutableStateOf("تهران") }
    var authSelectedCategories by remember { mutableStateOf(setOf<String>()) }

    var cartAddress by remember { mutableStateOf("") }
    var cartNotes by remember { mutableStateOf("") }
    var cartCardHolder by remember { mutableStateOf("") }
    var cartTrackNumber by remember { mutableStateOf("") }

    var payCardHolder by remember { mutableStateOf("") }
    var payTrackNumber by remember { mutableStateOf("") }

    // Live variables from ViewModel
    val currentUser by viewModel.currentUser.collectAsState()
    val isDatabaseLoading by viewModel.isDatabaseLoading.collectAsState()
    val isAuthLoading by viewModel.isAuthLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()

    val liveSpareParts by viewModel.liveSpareParts.collectAsState()
    val liveTechnicians by viewModel.liveTechnicians.collectAsState()
    val liveCommonProblems by viewModel.liveCommonProblems.collectAsState()

    val cartItemsList by viewModel.cart.collectAsState()
    val cartQtyMap by viewModel.cartQty.collectAsState()
    val isPurchaseLoading by viewModel.isPurchaseLoading.collectAsState()
    val purchaseSuccess by viewModel.purchaseSuccess.collectAsState()

    val repairOrders by viewModel.repairOrders.collectAsState()
    val isRepairsLoading by viewModel.isRepairsLoading.collectAsState()

    val isCardVerifyLoading by viewModel.isCardVerifyLoading.collectAsState()
    val cardVerifySuccess by viewModel.cardVerifySuccess.collectAsState()

    val freeErrorCount by viewModel.freeErrorCount.collectAsState()
    val freeProblemCount by viewModel.freeProblemCount.collectAsState()

    val isPremium = currentUser?.subscription?.is_premium == true

    // Trigger RTL context for Persian/Arabic UI
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            modifier = modifier
                .fillMaxSize()
                .background(CodyarBg),
            topBar = {
                Surface(
                    color = CodyarNavy,
                    shadowElevation = 4.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .statusBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .background(CodyarRed, RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Build,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(19.dp)
                                )
                            }
                            Column {
                                Text(
                                    text = "کدیار",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "لوازم خانگی",
                                    fontSize = 10.sp,
                                    color = Color.White.copy(alpha = 0.5f)
                                )
                            }
                        }

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (isPremium) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFC9A227), RoundedCornerShape(6.dp))
                                        .padding(horizontal = 8.dp, vertical = 3.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(3.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Star,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(10.dp)
                                        )
                                        Text(
                                            text = "ویژه",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Cart Button
                            Box {
                                IconButton(
                                    onClick = {
                                        if (cartItemsList.isNotEmpty()) {
                                            cartStep = "cart"
                                            showCartDialog = true
                                        } else {
                                            activeTab = "store"
                                        }
                                    },
                                    modifier = Modifier
                                        .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                        .size(36.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ShoppingCart,
                                        contentDescription = "سبد خرید",
                                        tint = Color.White,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }
                                if (cartItemsList.isNotEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopStart)
                                            .offset(x = (-3).dp, y = (-3).dp)
                                            .background(CodyarRed, CircleShape)
                                            .size(16.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = cartItemsList.size.toString(),
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }

                            // Profile Button
                            IconButton(
                                onClick = {
                                    if (currentUser != null) {
                                        activeTab = "profile"
                                    } else {
                                        authMode = "login"
                                        showAuthDialog = true
                                    }
                                },
                                modifier = Modifier
                                    .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                    .size(36.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Person,
                                    contentDescription = "پروفایل",
                                    tint = Color.White,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                    }
                }
            },
            bottomBar = {
                // Persistent bottom navigation matching exactly the HTML bottom bar
                Surface(
                    color = Color.White,
                    tonalElevation = 8.dp,
                    border = BorderStroke(1.dp, Color(0xFFEAECEF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val navigationItems = listOf(
                            Triple("home", Icons.Default.Home, "خانه"),
                            Triple("search", Icons.Default.Search, "کد خطا"),
                            Triple("problems", Icons.Default.Warning, "مشکلات"),
                            Triple("store", Icons.Default.ShoppingCart, "فروشگاه"),
                            Triple("profile", Icons.Default.Person, "پروفایل")
                        )

                        navigationItems.forEach { (id, icon, label) ->
                            val active = activeTab == id || (id == "profile" && activeTab == "orders") || (id == "search" && activeTab == "technicians")
                            val itemColor = if (active) CodyarRed else Color(0xFF4A5568)

                            Column(
                                modifier = Modifier
                                    .clickable {
                                        selectedErrorDetail = null
                                        selectedProblemDetail = null
                                        activeTab = id
                                    }
                                    .padding(horizontal = 10.dp, vertical = 5.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(3.dp)
                            ) {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = itemColor,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal,
                                    color = itemColor
                                )
                                if (active) {
                                    Box(
                                        modifier = Modifier
                                            .background(CodyarRed, RoundedCornerShape(2.dp))
                                            .width(20.dp)
                                            .height(2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .background(CodyarBg)
            ) {
                if (isDatabaseLoading) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = CodyarNavy)
                    }
                } else {
                    when (activeTab) {
                        "home" -> HomeScreen(
                            viewModel = viewModel,
                            onNavigateToSearch = { activeTab = "search" },
                            onNavigateToTechnicians = { activeTab = "technicians" },
                            onNavigateToStore = { activeTab = "store" },
                            onShowPlans = { showPlansDialog = true },
                            onOpenErrorCode = { err ->
                                selectedErrorDetail = err
                                activeTab = "search"
                            }
                        )
                        "search" -> SearchScreen(
                            viewModel = viewModel,
                            selectedErrorDetail = selectedErrorDetail,
                            onSelectError = { selectedErrorDetail = it },
                            onBack = { selectedErrorDetail = null },
                            onNavigateToTechnicians = { activeTab = "technicians" },
                            onNavigateToStore = { activeTab = "store" },
                            isPremium = isPremium,
                            freeErrorCount = freeErrorCount,
                            onShowPlans = { showPlansDialog = true }
                        )
                        "problems" -> ProblemsScreen(
                            viewModel = viewModel,
                            liveProblems = viewModel.liveCommonProblems,
                            selectedProblemDetail = selectedProblemDetail,
                            onSelectProblem = { selectedProblemDetail = it },
                            onBack = { selectedProblemDetail = null },
                            onNavigateToTechnicians = { activeTab = "technicians" },
                            isPremium = isPremium,
                            freeProblemCount = freeProblemCount,
                            onShowPlans = { showPlansDialog = true }
                        )
                        "store" -> StoreScreen(
                            viewModel = viewModel,
                            parts = liveSpareParts,
                            cartItems = cartItemsList,
                            onAddToCart = { viewModel.addToCart(it) }
                        )
                        "profile" -> ProfileScreen(
                            viewModel = viewModel,
                            currentUser = currentUser,
                            onShowAuth = {
                                authMode = "login"
                                showAuthDialog = true
                            },
                            onShowPlans = { showPlansDialog = true },
                            onNavigateToOrders = {
                                viewModel.loadRepairs()
                                activeTab = "orders"
                            },
                            onNavigateToSaved = { activeTab = "search" }
                        )
                        "technicians" -> TechniciansScreen(
                            viewModel = viewModel,
                            liveTechs = viewModel.liveTechnicians,
                            currentUser = currentUser,
                            onShowAuth = {
                                authMode = "login"
                                showAuthDialog = true
                            }
                        )
                        "orders" -> OrdersScreen(
                            viewModel = viewModel,
                            repairOrders = repairOrders,
                            isRepairsLoading = isRepairsLoading,
                            onBack = { activeTab = "profile" },
                            onNavigateToTechs = { activeTab = "technicians" }
                        )
                        "ai_chat" -> AiChatScreen(viewModel = viewModel)
                    }
                }
            }
        }

        // --- AUTH DIALOG ---
        if (showAuthDialog) {
            AlertDialog(
                onDismissRequest = { showAuthDialog = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (authMode == "login") "ورود به حساب کاربری" else "ثبت‌نام حساب جدید",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CodyarNavy
                        )
                        IconButton(onClick = { showAuthDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "بستن")
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Toggle bar for Login / Register
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFFF0F2F5), RoundedCornerShape(9.dp))
                                .padding(3.dp)
                        ) {
                            Button(
                                onClick = { authMode = "login" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (authMode == "login") Color.White else Color.Transparent,
                                    contentColor = if (authMode == "login") Color(0xFF1A1A2E) else Color(0xFF4A5568)
                                ),
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Text("ورود", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Button(
                                onClick = { authMode = "register" },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (authMode == "register") Color.White else Color.Transparent,
                                    contentColor = if (authMode == "register") Color(0xFF1A1A2E) else Color(0xFF4A5568)
                                ),
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Text("ثبت‌نام", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }

                        // Sub-toggle for Customer / Technician registration
                        if (authMode == "register") {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF8FAFC), RoundedCornerShape(9.dp))
                                    .border(1.dp, Color(0xFFE2E8F0), RoundedCornerShape(9.dp))
                                    .padding(3.dp)
                            ) {
                                Button(
                                    onClick = { authRole = "customer" },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (authRole == "customer") CodyarRed else Color.Transparent,
                                        contentColor = if (authRole == "customer") Color.White else Color(0xFF64748B)
                                    ),
                                    shape = RoundedCornerShape(7.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 6.dp)
                                ) {
                                    Text("ثبت‌نام مشتری", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                                Button(
                                    onClick = { authRole = "technician" },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (authRole == "technician") CodyarNavy else Color.Transparent,
                                        contentColor = if (authRole == "technician") Color.White else Color(0xFF64748B)
                                    ),
                                    shape = RoundedCornerShape(7.dp),
                                    modifier = Modifier.weight(1f),
                                    contentPadding = PaddingValues(vertical = 6.dp)
                                ) {
                                    Text("ثبت‌نام تکنسین", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }

                        if (authMode == "register") {
                            OutlinedTextField(
                                value = authName,
                                onValueChange = { authName = it },
                                placeholder = { Text("نام و نام خانوادگی") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(9.dp),
                                singleLine = true
                            )
                        }

                        OutlinedTextField(
                            value = authPhone,
                            onValueChange = { authPhone = it },
                            placeholder = { Text("شماره موبایل (مثلا: 0912...)") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(9.dp),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
                        )

                        OutlinedTextField(
                            value = authPassword,
                            onValueChange = { authPassword = it },
                            placeholder = { Text("رمز عبور") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(9.dp),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                        )

                        // Technician-specific fields
                        if (authMode == "register" && authRole == "technician") {
                            OutlinedTextField(
                                value = authCity,
                                onValueChange = { authCity = it },
                                placeholder = { Text("شهر محل فعالیت (مثلا: تهران)") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(9.dp),
                                singleLine = true
                            )

                            val availableCategories = listOf("ماشین لباسشویی", "ماشین ظرفشویی", "یخچال و فریزر", "مایکروویو", "جاروبرقی", "کولر گازی")
                            Text("انتخاب تخصص‌ها:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CodyarNavy)
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState())
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                availableCategories.forEach { cat ->
                                    val isSelected = authSelectedCategories.contains(cat)
                                    Box(
                                        modifier = Modifier
                                            .background(
                                                color = if (isSelected) CodyarRed else Color(0xFFF1F5F9),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .border(
                                                width = 1.dp,
                                                color = if (isSelected) CodyarRed else Color(0xFFCBD5E1),
                                                shape = RoundedCornerShape(16.dp)
                                            )
                                            .clickable {
                                                authSelectedCategories = if (isSelected) {
                                                    authSelectedCategories - cat
                                                } else {
                                                    authSelectedCategories + cat
                                                }
                                            }
                                            .padding(horizontal = 10.dp, vertical = 6.dp)
                                    ) {
                                        Text(
                                            text = cat,
                                            color = if (isSelected) Color.White else Color(0xFF475569),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }

                        if (authError != null) {
                            Text(
                                text = authError ?: "",
                                color = CodyarRed,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFFDF0EE), RoundedCornerShape(7.dp))
                                    .padding(8.dp)
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (authPhone.isBlank() || authPassword.isBlank()) {
                                Toast.makeText(context, "لطفاً تمام موارد را پر کنید", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (authMode == "login") {
                                viewModel.login(authPhone, authPassword) { success, err ->
                                    if (success) {
                                        showAuthDialog = false
                                        Toast.makeText(context, "خوش آمدید!", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            } else {
                                if (authName.isBlank()) {
                                    Toast.makeText(context, "نام الزامی است", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (authRole == "technician" && authCity.isBlank()) {
                                    Toast.makeText(context, "لطفاً شهر محل فعالیت را وارد کنید", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                if (authRole == "technician" && authSelectedCategories.isEmpty()) {
                                    Toast.makeText(context, "لطفاً حداقل یک تخصص انتخاب کنید", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                viewModel.register(
                                    phone = authPhone,
                                    pass = authPassword,
                                    name = authName,
                                    role = authRole,
                                    city = if (authRole == "technician") authCity else null,
                                    categories = if (authRole == "technician") authSelectedCategories.toList() else null
                                ) { success, err ->
                                    if (success) {
                                        showAuthDialog = false
                                        val welcomeMsg = if (authRole == "technician") {
                                            "ثبت‌نام تکنسین با موفقیت انجام شد! حساب شما فعال است."
                                        } else {
                                            "ثبت‌نام مشتری با موفقیت انجام شد!"
                                        }
                                        Toast.makeText(context, welcomeMsg, Toast.LENGTH_LONG).show()
                                    }
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CodyarRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("login_button"),
                        shape = RoundedCornerShape(10.dp),
                        enabled = !isAuthLoading
                    ) {
                        if (isAuthLoading) {
                            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                        } else {
                            Text(
                                text = if (authMode == "login") "ورود به حساب" else if (authRole == "technician") "ثبت‌نام تکنسین" else "ثبت‌نام مشتری",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            )
        }

        // --- CART DIALOG ---
        if (showCartDialog) {
            AlertDialog(
                onDismissRequest = { showCartDialog = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (cartStep == "cart") "سبد خرید قطعات شما" else "پرداخت کارت به کارت",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CodyarNavy
                        )
                        IconButton(onClick = { showCartDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "بستن")
                        }
                    }
                },
                text = {
                    val scrollState = rememberScrollState()
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(scrollState),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (!purchaseSuccess) {
                            if (cartStep == "cart") {
                                // Cart item list
                                cartItemsList.forEach { partId ->
                                    val part = liveSpareParts.find { it.id == partId }
                                    if (part != null) {
                                        val qty = cartQtyMap[partId] ?: 1
                                        val subtotal = (part.price ?: 0.0) * qty

                                        Card(
                                            modifier = Modifier.fillMaxWidth(),
                                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF7F8FA)),
                                            shape = RoundedCornerShape(12.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(10.dp),
                                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .size(56.dp)
                                                        .background(Color.White, RoundedCornerShape(8.dp)),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    val finalImg = part.image ?: part.imageUrl ?: ""
                                                    if (finalImg.isNotEmpty()) {
                                                        AsyncImage(
                                                            model = if (finalImg.startsWith("http")) finalImg else "https://kodyar24.ir/${finalImg.removePrefix("/")}",
                                                            contentDescription = part.name,
                                                            modifier = Modifier
                                                                .fillMaxSize()
                                                                .clip(RoundedCornerShape(8.dp))
                                                        )
                                                    } else {
                                                        Text("⚙️", fontSize = 24.sp)
                                                    }
                                                }
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(
                                                        part.name ?: "",
                                                        fontWeight = FontWeight.Bold,
                                                        fontSize = 13.sp,
                                                        color = Color(0xFF1A1A2E)
                                                    )
                                                    Text(
                                                        "${formatToman(part.price ?: 0.0)} تومان",
                                                        fontSize = 11.sp,
                                                        color = Color(0xFF4A5568)
                                                    )
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Row(
                                                        verticalAlignment = Alignment.CenterVertically,
                                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                    ) {
                                                        IconButton(
                                                            onClick = { viewModel.updateCartQty(partId, qty - 1) },
                                                            modifier = Modifier
                                                                .border(1.dp, Color(0xFFDDE1E7), RoundedCornerShape(5.dp))
                                                                .size(26.dp)
                                                        ) {
                                                            Text("−", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                        Text(
                                                            text = qty.toString(),
                                                            fontWeight = FontWeight.Bold,
                                                            fontSize = 13.sp,
                                                            modifier = Modifier.width(22.dp),
                                                            textAlign = TextAlign.Center
                                                        )
                                                        IconButton(
                                                            onClick = { viewModel.updateCartQty(partId, qty + 1) },
                                                            modifier = Modifier
                                                                .border(1.dp, Color(0xFFDDE1E7), RoundedCornerShape(5.dp))
                                                                .size(26.dp)
                                                        ) {
                                                            Text("+", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                                                        }

                                                        Spacer(modifier = Modifier.weight(1f))

                                                        TextButton(
                                                            onClick = { viewModel.removeFromCart(partId) },
                                                            colors = ButtonDefaults.textButtonColors(contentColor = CodyarRed)
                                                        ) {
                                                            Text("حذف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                // Total row
                                val total = cartItemsList.sumOf { partId ->
                                    val part = liveSpareParts.find { it.id == partId }
                                    val qty = cartQtyMap[partId] ?: 1
                                    (part?.price ?: 0.0) * qty
                                }

                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("جمع کل اقلام:", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                                    Text(
                                        "${formatToman(total)} تومان",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = CodyarRed
                                    )
                                }

                                // Form inputs
                                Text("آدرس دقیق تحویل قطعه *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = cartAddress,
                                    onValueChange = { cartAddress = it },
                                    placeholder = { Text("استان، شهر، خیابان، پلاک، واحد...") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(9.dp),
                                    maxLines = 3
                                )

                                Text("توضیحات سفارش (اختیاری)", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = cartNotes,
                                    onValueChange = { cartNotes = it },
                                    placeholder = { Text("مثلاً: ساعت تحویل یا توضیحات اضافه") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(9.dp),
                                    singleLine = true
                                )
                            } else {
                                // Payment Step
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = CodyarNavy)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(16.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.spacedBy(5.dp)
                                    ) {
                                        Text("شماره کارت جهت کارت به کارت", fontSize = 11.sp, color = Color.White.copy(alpha = 0.6f))
                                        Text("6104-3389-6112-6667", fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 2.sp)
                                        Text("به نام: مهدی عباسی (مدیریت کدیار)", fontSize = 11.sp, color = Color.White.copy(alpha = 0.5f))
                                    }
                                }

                                Text("نام صاحب کارت واریزکننده *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = cartCardHolder,
                                    onValueChange = { cartCardHolder = it },
                                    placeholder = { Text("نام کامل صاحب کارت بانکی") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(9.dp),
                                    singleLine = true
                                )

                                Text("شماره پیگیری تراکنش / فیش پرداخت *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                OutlinedTextField(
                                    value = cartTrackNumber,
                                    onValueChange = { cartTrackNumber = it },
                                    placeholder = { Text("شماره ارجاع، پیگیری یا شماره فیش تراکنش") },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(9.dp),
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                                )
                            }
                        } else {
                            // Success state
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .background(Color(0xFFEAFAF1), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("✅", fontSize = 34.sp)
                                }
                                Text("سفارش شما با موفقیت ثبت شد!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color(0xFF1A1A2E))
                                Text(
                                    "فیش واریزی شما ثبت شد و پس از بررسی و تایید مدیریت در سریع‌ترین زمان قطعه برای شما ارسال می‌گردد.",
                                    fontSize = 13.sp,
                                    color = Color(0xFF374151),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (!purchaseSuccess) {
                        Button(
                            onClick = {
                                if (cartStep == "cart") {
                                    if (cartAddress.isBlank()) {
                                        Toast.makeText(context, "وارد کردن آدرس تحویل الزامی است", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    if (currentUser == null) {
                                        showCartDialog = false
                                        authMode = "login"
                                        showAuthDialog = true
                                        Toast.makeText(context, "لطفاً ابتدا وارد حساب خود شوید", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    cartStep = "payment"
                                } else {
                                    if (cartCardHolder.isBlank() || cartTrackNumber.isBlank()) {
                                        Toast.makeText(context, "لطفاً تمام فیلدهای پرداخت را پر کنید", Toast.LENGTH_SHORT).show()
                                        return@Button
                                    }
                                    viewModel.submitPurchase(
                                        address = cartAddress,
                                        notes = cartNotes,
                                        cardHolder = cartCardHolder,
                                        trackNumber = cartTrackNumber
                                    ) { success, err ->
                                        if (success) {
                                            cartAddress = ""
                                            cartNotes = ""
                                            cartCardHolder = ""
                                            cartTrackNumber = ""
                                        } else {
                                            Toast.makeText(context, err ?: "خطا در ثبت نهایی", Toast.LENGTH_LONG).show()
                                        }
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E8449)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("submit_order_button"),
                            shape = RoundedCornerShape(11.dp),
                            enabled = !isPurchaseLoading
                        ) {
                            if (isPurchaseLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            } else {
                                Text(
                                    text = if (cartStep == "cart") "ادامه به پرداخت فیش" else "✓ ثبت نهایی فیش پرداخت",
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                showCartDialog = false
                                viewModel.clearCart()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("متوجه شدم", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }

        // --- SUBSCRIPTION PLANS DIALOG ---
        if (showPlansDialog) {
            val plansList = listOf(
                mapOf("id" to "1_month", "name" to "اشتراک طلایی — یک ماهه", "price" to 120000.0, "tag" to "پرطرفدار"),
                mapOf("id" to "3_month", "name" to "اشتراک نقره‌ای — سه ماهه", "price" to 290000.0, "tag" to ""),
                mapOf("id" to "6_month", "name" to "اشتراک الماس — شش ماهه", "price" to 490000.0, "tag" to "بهترین ارزش")
            )

            AlertDialog(
                onDismissRequest = { showPlansDialog = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "خرید اشتراک ویژه کدیار",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = CodyarNavy
                        )
                        IconButton(onClick = { showPlansDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "بستن")
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            "با تهیه اشتراک ویژه، دسترسی نامحدود به کدهای خطای تخصصی کل لوازم خانگی و پاسخ مشکلات عیب‌یابی در طول دوره برای شما فعال می‌شود.",
                            fontSize = 12.sp,
                            color = Color(0xFF4A5568),
                            lineHeight = 20.sp
                        )

                        plansList.forEach { plan ->
                            val hasTag = (plan["tag"] as String).isNotEmpty()
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                border = if (hasTag) BorderStroke(2.dp, Color(0xFFC9A227)) else BorderStroke(1.dp, Color(0xFFEAECEF)),
                                colors = CardDefaults.cardColors(containerColor = Color.White),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Column(modifier = Modifier.fillMaxWidth()) {
                                    if (hasTag) {
                                        Box(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFC9A227))
                                                .padding(vertical = 4.dp),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = plan["tag"] as String,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                        }
                                    }
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        verticalArrangement = Arrangement.spacedBy(10.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                plan["name"] as String,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp,
                                                color = Color(0xFF1A1A2E)
                                            )
                                            Text(
                                                "${formatToman(plan["price"] as Double)} ت",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = Color(0xFFC9A227)
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                if (currentUser == null) {
                                                    showPlansDialog = false
                                                    authMode = "login"
                                                    showAuthDialog = true
                                                    Toast.makeText(context, "ابتدا وارد حساب کاربری شوید", Toast.LENGTH_SHORT).show()
                                                    return@Button
                                                }
                                                selectedPlanForPay = plan
                                                showPlansDialog = false
                                                viewModel.resetCardVerifySuccess()
                                                showPayDialog = true
                                            },
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (hasTag) Color(0xFFC9A227) else CodyarNavy
                                            ),
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(10.dp)
                                        ) {
                                            Text("خرید و فعال‌سازی اشتراک", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {}
            )
        }

        // --- PAYMENT DIALOG ---
        if (showPayDialog && selectedPlanForPay != null) {
            val plan = selectedPlanForPay!!
            AlertDialog(
                onDismissRequest = { showPayDialog = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "کارت به کارت جهت ارتقا اشتراک",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = CodyarNavy
                            )
                            Text(
                                text = "${plan["name"]} — ${formatToman(plan["price"] as Double)} تومان",
                                fontSize = 11.sp,
                                color = Color(0xFF4A5568)
                            )
                        }
                        IconButton(onClick = { showPayDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "بستن")
                        }
                    }
                },
                text = {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        if (!cardVerifySuccess) {
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                colors = CardDefaults.cardColors(containerColor = CodyarNavy)
                            ) {
                                Column(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.spacedBy(3.dp)
                                ) {
                                    Text("شماره کارت جهت واریز", fontSize = 10.sp, color = Color.White.copy(alpha = 0.6f))
                                    Text("6104-3389-6112-6667", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Color.White, letterSpacing = 2.sp)
                                    Text("به نام: مهدی عباسی (مدیریت کدیار)", fontSize = 10.sp, color = Color.White.copy(alpha = 0.5f))
                                }
                            }

                            Text("نام صاحب کارت واریزکننده *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = payCardHolder,
                                onValueChange = { payCardHolder = it },
                                placeholder = { Text("نام کامل صاحب فیش") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(9.dp),
                                singleLine = true
                            )

                            Text("شماره ارجاع / پیگیری تراکنش *", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            OutlinedTextField(
                                value = payTrackNumber,
                                onValueChange = { payTrackNumber = it },
                                placeholder = { Text("مثلاً: 123456789") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(9.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                            )
                        } else {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 15.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .background(Color(0xFFEAFAF1), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("✅", fontSize = 30.sp)
                                }
                                Text("فیش پرداخت با موفقیت ثبت شد!", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1A1A2E))
                                Text(
                                    "فیش واریزی اشتراک شما ثبت شد و حداکثر پس از ۲ ساعت توسط مدیریت بررسی و تایید می‌گردد.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF374151),
                                    textAlign = TextAlign.Center,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                },
                confirmButton = {
                    if (!cardVerifySuccess) {
                        Button(
                            onClick = {
                                if (payCardHolder.isBlank() || payTrackNumber.isBlank()) {
                                    Toast.makeText(context, "لطفاً تمام موارد را پر کنید", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                viewModel.submitCardVerify(
                                    cardHolder = payCardHolder,
                                    trackNumber = payTrackNumber,
                                    productId = plan["id"] as String
                                ) { success, err ->
                                    if (success) {
                                        payCardHolder = ""
                                        payTrackNumber = ""
                                    } else {
                                        Toast.makeText(context, err ?: "خطا", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E8449)),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(11.dp),
                            enabled = !isCardVerifyLoading
                        ) {
                            if (isCardVerifyLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                            } else {
                                Text("✓ ثبت فیش پرداخت", fontWeight = FontWeight.Bold)
                            }
                        }
                    } else {
                        Button(
                            onClick = {
                                showPayDialog = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("متوجه شدم", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
    }
}

// --- TAB 1: HOME SCREEN ---
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(
    viewModel: AssistantViewModel,
    onNavigateToSearch: () -> Unit,
    onNavigateToTechnicians: () -> Unit,
    onNavigateToStore: () -> Unit,
    onShowPlans: () -> Unit,
    onOpenErrorCode: (KodyarErrorCode) -> Unit
) {
    val scrollState = rememberScrollState()
    var homeSearchQuery by remember { mutableStateOf("") }
    val liveErrorCodes by viewModel.liveErrorCodes.collectAsState()
    val liveTechs by viewModel.liveTechnicians.collectAsState()
    val liveParts by viewModel.liveSpareParts.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
    ) {
        // Hero search banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(CodyarNavy)
                .padding(horizontal = 16.dp, vertical = 24.dp)
        ) {
            Column {
                Text(
                    text = "مرجع عیب‌یابی لوازم خانگی",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.6f),
                    modifier = Modifier.padding(bottom = 6.dp)
                )
                Text(
                    text = "کد خطای دستگاه را\nسریع پیدا کنید",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    lineHeight = 32.sp,
                    modifier = Modifier.padding(bottom = 18.dp)
                )

                // Search field
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.White, RoundedCornerShape(12.dp))
                        .padding(5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "جستجو",
                        tint = Color(0xFF4A5568),
                        modifier = Modifier
                            .padding(start = 12.dp, end = 8.dp)
                            .size(16.dp)
                    )
                    Box(modifier = Modifier.weight(1f)) {
                        if (homeSearchQuery.isEmpty()) {
                            Text(
                                "مثلاً: E1، F2، بوتان...",
                                color = Color(0xFFB0B8C4),
                                fontSize = 13.sp
                            )
                        }
                        BasicTextField(
                            value = homeSearchQuery,
                            onValueChange = { homeSearchQuery = it },
                            modifier = Modifier.fillMaxWidth(),
                            textStyle = LocalTextStyle.current.copy(
                                fontSize = 13.sp,
                                color = Color(0xFF1A1A2E),
                                textAlign = TextAlign.Start
                            )
                        )
                    }
                    Button(
                        onClick = {
                            viewModel.updateSearchFilters(homeSearchQuery, "همه", "همه")
                            onNavigateToSearch()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = CodyarRed),
                        shape = RoundedCornerShape(9.dp),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 9.dp)
                    ) {
                        Text("جستجو", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }

        // Stats card (Floating offset over hero)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .offset(y = (-20).dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            shape = RoundedCornerShape(14.dp),
            border = BorderStroke(1.dp, Color(0xFFEAECEF))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Stat 1
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🔴", fontSize = 17.sp)
                    Text(
                        text = if (liveErrorCodes.isNotEmpty()) "${liveErrorCodes.size}+" else "۵۰۰+",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1A1A2E)
                    )
                    Text("کد خطا", fontSize = 10.sp, color = Color(0xFF4A5568))
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .background(Color(0xFFEAECEF))
                        .width(1.dp)
                        .height(35.dp)
                )

                // Stat 2
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("🔧", fontSize = 17.sp)
                    Text(
                        text = if (liveTechs.isNotEmpty()) "${liveTechs.size}+" else "۲۰۰+",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1A1A2E)
                    )
                    Text("تکنسین", fontSize = 10.sp, color = Color(0xFF4A5568))
                }

                // Vertical Divider
                Box(
                    modifier = Modifier
                        .background(Color(0xFFEAECEF))
                        .width(1.dp)
                        .height(35.dp)
                )

                // Stat 3
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.weight(1f)
                ) {
                    Text("📦", fontSize = 17.sp)
                    Text(
                        text = if (liveParts.isNotEmpty()) "${liveParts.size}+" else "۱۰۰۰+",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color(0xFF1A1A2E)
                    )
                    Text("قطعه", fontSize = 10.sp, color = Color(0xFF4A5568))
                }
            }
        }

        // Quick action grid (4 actions)
        FlowRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp)
                .offset(y = (-10).dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            maxItemsInEachRow = 2
        ) {
            val quickActions = listOf(
                QuadAction(
                    icon = Icons.Default.Search,
                    tint = CodyarRed,
                    label = "جستجوی کد خطا",
                    sub = "عیب‌یابی سریع",
                    action = onNavigateToSearch
                ),
                QuadAction(
                    icon = Icons.Default.Build,
                    tint = CodyarNavy,
                    label = "اعزام تکنسین",
                    sub = "در شهر شما",
                    action = onNavigateToTechnicians
                ),
                QuadAction(
                    icon = Icons.Default.ShoppingCart,
                    tint = Color(0xFF1E8449),
                    label = "فروشگاه قطعات",
                    sub = "قطعات اصل",
                    action = onNavigateToStore
                ),
                QuadAction(
                    icon = Icons.Default.Star,
                    tint = Color(0xFFC9A227),
                    label = "اشتراک ویژه",
                    sub = "از ۱۲۰,۰۰۰ تومان",
                    action = onShowPlans
                )
            )

            quickActions.forEach { item ->
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { item.action() }
                        .padding(vertical = 5.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFEAECEF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                BorderStroke(0.dp, Color.Transparent)
                            )
                            .padding(horizontal = 12.dp, vertical = 14.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(item.tint.copy(alpha = 0.1f), CircleShape)
                                .padding(8.dp)
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = item.tint,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = item.label,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1A1A2E)
                            )
                            Text(
                                text = item.sub,
                                fontSize = 10.sp,
                                color = Color(0xFF4A5568)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // High frequency errors header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = CodyarRed,
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = "پرتکرارترین خطاها",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1A1A2E)
                )
            }

            TextButton(onClick = onNavigateToSearch) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    Text("همه", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CodyarRed)
                    Icon(
                        imageVector = Icons.Default.ArrowForward, // Mirrored dynamically
                        contentDescription = null,
                        tint = CodyarRed,
                        modifier = Modifier.size(11.dp)
                    )
                }
            }
        }

        // List of top 5 errors
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            liveErrorCodes.take(5).forEach { err ->
                val severityLevel = err.hazardLevel ?: "medium"
                val (color, bg, label) = when (severityLevel) {
                    "high" -> Triple(Color(0xFFC0392B), Color(0xFFFDF0EE), "خطرناک")
                    "low" -> Triple(Color(0xFF1E8449), Color(0xFFEAFAF1), "کم‌خطر")
                    else -> Triple(Color(0xFFD68910), Color(0xFFFEF9E7), "متوسط")
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onOpenErrorCode(err) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFEAECEF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(11.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .background(Color(0xFFF0F2F5), RoundedCornerShape(9.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = err.code ?: "",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF374151)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = err.title ?: err.code ?: "",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF1A1A2E),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = "${err.brand ?: ""} · ${err.category ?: ""}",
                                fontSize = 11.sp,
                                color = Color(0xFF4A5568)
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(bg, RoundedCornerShape(5.dp))
                                .padding(horizontal = 7.dp, vertical = 3.dp)
                        ) {
                            Text(
                                text = label,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = color
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}

data class QuadAction(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tint: Color,
    val label: String,
    val sub: String,
    val action: () -> Unit
)

// --- Helper Functions ---
fun formatToman(price: Double): String {
    return String.format("%,.0f", price)
}

@Composable
fun BasicTextField(
    value: String,
    onValueChange: (String) -> Unit,
    modifier: Modifier = Modifier,
    textStyle: androidx.compose.ui.text.TextStyle = LocalTextStyle.current
) {
    androidx.compose.foundation.text.BasicTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = modifier,
        textStyle = textStyle,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text)
    )
}

// --- TAB 2: SEARCH / ERROR CODES ---
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(
    viewModel: AssistantViewModel,
    selectedErrorDetail: KodyarErrorCode?,
    onSelectError: (KodyarErrorCode) -> Unit,
    onBack: () -> Unit,
    onNavigateToTechnicians: () -> Unit,
    onNavigateToStore: () -> Unit,
    isPremium: Boolean,
    freeErrorCount: Int,
    onShowPlans: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val speechRecognizerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val data = result.data
            val results = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = results?.firstOrNull() ?: ""
            if (spokenText.isNotEmpty()) {
                viewModel.updateSearchFilters(spokenText, viewModel.selectedBrand.value, viewModel.selectedCategory.value)
            }
        }
    }

    val searchQuery by viewModel.searchQuery.collectAsState()
    val selectedBrand by viewModel.selectedBrand.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()
    val savedErrors by viewModel.savedErrors.collectAsState()

    val liveCategories by viewModel.liveCategories.collectAsState()
    val liveBrands by viewModel.liveBrands.collectAsState()

    var showFilterBar by remember { mutableStateOf(false) }

    if (selectedErrorDetail == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchFilters(it, selectedBrand, selectedCategory) },
                placeholder = { Text("کد خطا، برند، دستگاه یا شرح عیب...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
                trailingIcon = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(end = 4.dp)
                    ) {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchFilters("", selectedBrand, selectedCategory) }) {
                                Icon(Icons.Default.Close, contentDescription = "پاک کردن", tint = Color(0xFF64748B))
                            }
                        }
                        IconButton(onClick = {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "لطفاً عیب یا کد خطا را بگویید...")
                            }
                            try {
                                speechRecognizerLauncher.launch(intent)
                            } catch (e: Exception) {
                                Toast.makeText(context, "سیستم صوتی روی این دستگاه در دسترس نیست", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Icon(Icons.Default.Mic, contentDescription = "جستجوی صوتی", tint = CodyarRed)
                        }
                    }
                },
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CodyarNavy,
                    unfocusedBorderColor = Color(0xFFDDE1E7)
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Expandable Filter Chip
            Card(
                onClick = { showFilterBar = !showFilterBar },
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, Color(0xFFEAECEF))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 13.dp, vertical = 9.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.List,
                            contentDescription = null,
                            tint = if (showFilterBar) CodyarRed else Color(0xFF374151)
                        )
                        Text(
                            text = "فیلتر پیشرفته",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (showFilterBar) CodyarRed else Color(0xFF374151)
                        )
                        if (selectedCategory != "همه" || selectedBrand != "همه") {
                            Box(
                                modifier = Modifier
                                    .background(CodyarRed, CircleShape)
                                    .padding(horizontal = 7.dp, vertical = 1.dp)
                            ) {
                                Text("فعال", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                    Icon(
                        imageVector = if (showFilterBar) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Color(0xFF4A5568)
                    )
                }
            }

            AnimatedVisibility(visible = showFilterBar) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Category Horizontal Chips
                        Column {
                            Text(
                                "نوع دستگاه:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF374151),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                liveCategories.forEach { cat ->
                                    val active = selectedCategory == cat
                                    AssistChip(
                                        onClick = { viewModel.updateSearchFilters(searchQuery, selectedBrand, cat) },
                                        label = { Text(cat, fontSize = 12.sp) },
                                        colors = AssistChipDefaults.assistChipColors(
                                            containerColor = if (active) CodyarNavy else Color(0xFFF0F2F5),
                                            labelColor = if (active) Color.White else Color(0xFF374151)
                                        )
                                    )
                                }
                            }
                        }

                        // Brand Horizontal Chips
                        Column {
                            Text(
                                "برند:",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF374151),
                                modifier = Modifier.padding(bottom = 6.dp)
                            )
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(5.dp)
                            ) {
                                liveBrands.forEach { brand ->
                                    val active = selectedBrand == brand
                                    AssistChip(
                                        onClick = { viewModel.updateSearchFilters(searchQuery, brand, selectedCategory) },
                                        label = { Text(brand, fontSize = 12.sp) },
                                        colors = AssistChipDefaults.assistChipColors(
                                            containerColor = if (active) CodyarNavy else Color(0xFFF0F2F5),
                                            labelColor = if (active) Color.White else Color(0xFF374151)
                                        )
                                    )
                                }
                            }
                        }

                        if (selectedCategory != "همه" || selectedBrand != "همه") {
                            OutlinedButton(
                                onClick = { viewModel.updateSearchFilters("", "همه", "همه") },
                                shape = RoundedCornerShape(7.dp),
                                modifier = Modifier.align(Alignment.End),
                                border = BorderStroke(1.dp, Color(0xFFD1D5DB))
                            ) {
                                Text("× پاک کردن فیلترها", fontSize = 11.sp, color = Color(0xFF374151))
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "${searchResults.size} نتیجه یافت شد",
                fontSize = 11.sp,
                color = Color(0xFF4A5568),
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Results List
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                items(searchResults) { err ->
                    val severityLevel = err.hazardLevel ?: "medium"
                    val (color, bg, label) = when (severityLevel) {
                        "high" -> Triple(Color(0xFFC0392B), Color(0xFFFDF0EE), "خطرناک")
                        "low" -> Triple(Color(0xFF1E8449), Color(0xFFEAFAF1), "کم‌خطر")
                        else -> Triple(Color(0xFFD68910), Color(0xFFFEF9E7), "متوسط")
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (isPremium) {
                                    onSelectError(err)
                                } else {
                                    if (freeErrorCount < 5) {
                                        viewModel.useFreeCount("error") {
                                            onSelectError(err)
                                        }
                                    } else {
                                        onShowPlans()
                                    }
                                }
                            },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFEAECEF))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(11.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFFF0F2F5), RoundedCornerShape(9.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = err.code ?: "",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF374151)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = err.title ?: err.code ?: "",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1A1A2E),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${err.brand ?: ""} · ${err.category ?: ""}",
                                    fontSize = 11.sp,
                                    color = Color(0xFF4A5568)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .background(bg, RoundedCornerShape(5.dp))
                                    .padding(horizontal = 7.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = color
                                )
                            }
                        }
                    }
                }

                if (searchResults.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text("❌", fontSize = 36.sp)
                            Text("نتیجه‌ای پیدا نشد", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("کد خطا یا برند را بررسی کنید", fontSize = 12.sp, color = Color(0xFF4A5568))
                        }
                    }
                }
            }
        }
    } else {
        // ERROR DETAIL SCREEN
        val err = selectedErrorDetail
        val isBookmarked = savedErrors.any { it.code == err.code && it.brand == err.brand && it.category == err.category }

        val severityLevel = err.hazardLevel ?: "medium"
        val (themeColor, bgText, titleText) = when (severityLevel) {
            "high" -> Triple(Color(0xFFC0392B), Color(0xFFFDF0EE), "بحرانی / خطرناک")
            "low" -> Triple(Color(0xFF1E8449), Color(0xFFEAFAF1), "آسان / کم‌خطر")
            else -> Triple(Color(0xFFD68910), Color(0xFFFEF9E7), "متوسط")
        }

        val scrollState = rememberScrollState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .verticalScroll(scrollState)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = onBack,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = Color(0xFF374151)
                    ),
                    border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(5.dp)
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(14.dp))
                        Text("بازگشت", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                // Bookmark Icon
                IconButton(
                    onClick = {
                        viewModel.toggleSavedError(err.code ?: "", err.brand ?: "", err.category ?: "", isBookmarked)
                        Toast.makeText(
                            context,
                            if (isBookmarked) "از ذخیره‌شده‌ها حذف شد" else "به ذخیره‌شده‌ها اضافه شد",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "ذخیره",
                        tint = if (isBookmarked) Color.Red else Color.Gray
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Main Detail Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Header colored based on hazard level
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(themeColor)
                            .padding(horizontal = 16.dp, vertical = 18.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color.White.copy(alpha = 0.2f), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = err.code ?: "",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }

                            Column {
                                Text(
                                    text = err.title ?: "بررسی ارور ${err.code}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = Color.White
                                )
                                Text(
                                    text = "${err.brand ?: ""} · ${err.category ?: ""}",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.75f),
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                        }
                    }

                    // Content Padding
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Description
                        if (!err.description.isNullOrBlank()) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(bottom = 9.dp)
                                ) {
                                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFFD68910), modifier = Modifier.size(14.dp))
                                    Text("توضیح خطا", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
                                }

                                Text(
                                    text = err.description,
                                    fontSize = 15.sp,
                                    color = Color(0xFF1A1A2E),
                                    lineHeight = 30.sp,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .background(Color(0xFFFEF9E7), RoundedCornerShape(10.dp))
                                        .border(BorderStroke(1.dp, Color(0xFFFEF9E7)))
                                        .padding(14.dp)
                                )
                            }
                        }

                        // Causes List
                        val causesList = with(viewModel) { err.causes.toListOfStrings() }
                        if (causesList.isNotEmpty()) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(bottom = 9.dp)
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFC0392B), modifier = Modifier.size(14.dp))
                                    Text("علت‌های احتمالی", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    causesList.forEachIndexed { i, cause ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFFDF0EE), RoundedCornerShape(9.dp))
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "${i + 1}.",
                                                color = Color(0xFFC0392B),
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = cause,
                                                fontSize = 15.sp,
                                                color = Color(0xFF1A1A2E),
                                                lineHeight = 26.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Steps list
                        val stepsList = with(viewModel) { err.steps.toListOfStrings() }
                        if (stepsList.isNotEmpty()) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(bottom = 9.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF1E8449), modifier = Modifier.size(14.dp))
                                    Text("مراحل رفع مشکل", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    stepsList.forEachIndexed { i, step ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFEAFAF1), RoundedCornerShape(9.dp))
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(22.dp)
                                                    .background(Color(0xFF1E8449), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = (i + 1).toString(),
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Text(
                                                text = step,
                                                fontSize = 15.sp,
                                                color = Color(0xFF1A1A2E),
                                                lineHeight = 26.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = onNavigateToTechnicians,
                                colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("اعزام تکنسین")
                            }

                            Button(
                                onClick = onNavigateToStore,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E8449)),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("قطعات یدکی")
                            }
                        }

                        // Copy Button
                        TextButton(
                            onClick = {
                                clipboardManager.setText(
                                    AnnotatedString(
                                        "${err.brand} - ${err.category}\nکد خطا: ${err.code}\nشرح عیب: ${err.description ?: ""}\nمراحل حل: ${stepsList.joinToString("\n")}"
                                    )
                                )
                                Toast.makeText(context, "اطلاعات عیب‌یابی کپی شد!", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Text("کپی متن خطایابی", fontWeight = FontWeight.Bold, color = CodyarRed)
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 3: COMMON PROBLEMS SCREEN ---
@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun ProblemsScreen(
    viewModel: AssistantViewModel,
    liveProblems: StateFlow<List<KodyarCommonProblem>>,
    selectedProblemDetail: KodyarCommonProblem?,
    onSelectProblem: (KodyarCommonProblem) -> Unit,
    onBack: () -> Unit,
    onNavigateToTechnicians: () -> Unit,
    isPremium: Boolean,
    freeProblemCount: Int,
    onShowPlans: () -> Unit
) {
    val context = LocalContext.current
    val problemsList by liveProblems.collectAsState()
    var problemsSearchQuery by remember { mutableStateOf("") }

    if (selectedProblemDetail == null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
        ) {
            Text(
                "مشکلات رایج لوازم خانگی",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = CodyarNavy,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            if (!isPremium) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9E7)),
                    border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 13.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFF92400E))
                        Text(
                            text = "کاربران رایگان روزانه ۲ مشکل میتوانند مشاهده کنند",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF92400E)
                        )
                    }
                }
            }

            // Search within problems
            OutlinedTextField(
                value = problemsSearchQuery,
                onValueChange = { problemsSearchQuery = it },
                placeholder = { Text("جستجو در مشکلات...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "جستجو") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CodyarNavy,
                    unfocusedBorderColor = Color(0xFFDDE1E7)
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Problem Item lists
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filtered = problemsList.filter {
                    problemsSearchQuery.isEmpty() ||
                            (it.title ?: "").contains(problemsSearchQuery, ignoreCase = true) ||
                            (it.brand ?: "").contains(problemsSearchQuery, ignoreCase = true) ||
                            (it.category ?: "").contains(problemsSearchQuery, ignoreCase = true)
                }

                items(filtered) { prob ->
                    Card(
                        onClick = {
                            if (isPremium) {
                                onSelectProblem(prob)
                            } else {
                                if (freeProblemCount < 2) {
                                    viewModel.useFreeCount("problem") {
                                        onSelectProblem(prob)
                                    }
                                } else {
                                    onShowPlans()
                                }
                            }
                        },
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, Color(0xFFEAECEF))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(Color(0xFFF0F2F5), RoundedCornerShape(10.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🔧", fontSize = 22.sp)
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = prob.title ?: "",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1A1A2E),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "${prob.brand ?: ""} ${if (!prob.category.isNullOrBlank()) "· ${prob.category}" else ""}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF4A5568)
                                )
                            }

                            Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null, tint = Color(0xFF4A5568))
                        }
                    }
                }
            }
        }
    } else {
        // PROBLEM DETAIL VIEW SCREEN
        val prob = selectedProblemDetail
        val scrollState = rememberScrollState()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp)
                .verticalScroll(scrollState)
        ) {
            Button(
                onClick = onBack,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF374151)
                ),
                border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(14.dp))
                    Text("بازگشت", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(CodyarNavy)
                            .padding(horizontal = 16.dp, vertical = 18.dp)
                    ) {
                        Column {
                            Text(
                                text = prob.title ?: "",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = Color.White
                            )
                            Text(
                                text = "${prob.brand ?: ""} ${if (!prob.category.isNullOrBlank()) "· ${prob.category}" else ""}",
                                fontSize = 12.sp,
                                color = Color.White.copy(alpha = 0.7f),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }

                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Description
                        if (!prob.description.isNullOrBlank()) {
                            Text(
                                text = prob.description,
                                fontSize = 15.sp,
                                color = Color(0xFF1A1A2E),
                                lineHeight = 30.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF7F8FA), RoundedCornerShape(10.dp))
                                    .padding(14.dp)
                            )
                        }

                        // Causes
                        val causesList = with(viewModel) { prob.causes.toListOfStrings() }
                        if (causesList.isNotEmpty()) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(bottom = 9.dp)
                                ) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFC0392B), modifier = Modifier.size(14.dp))
                                    Text("علت‌های احتمالی", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    causesList.forEachIndexed { i, cause ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFFDF0EE), RoundedCornerShape(9.dp))
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Text(
                                                text = "${i + 1}.",
                                                color = Color(0xFFC0392B),
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = cause,
                                                fontSize = 15.sp,
                                                color = Color(0xFF1A1A2E),
                                                lineHeight = 26.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        // Solutions / Steps
                        val solList = with(viewModel) { prob.steps.toListOfStrings() }
                        if (solList.isNotEmpty()) {
                            Column {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(5.dp),
                                    modifier = Modifier.padding(bottom = 9.dp)
                                ) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF1E8449), modifier = Modifier.size(14.dp))
                                    Text("راه‌حل و مراحل رفع", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF374151))
                                }

                                Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                    solList.forEachIndexed { i, sol ->
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .background(Color(0xFFEAFAF1), RoundedCornerShape(9.dp))
                                                .padding(horizontal = 14.dp, vertical = 12.dp),
                                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(22.dp)
                                                    .background(Color(0xFF1E8449), CircleShape),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = (i + 1).toString(),
                                                    color = Color.White,
                                                    fontSize = 12.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                            Text(
                                                text = sol,
                                                fontSize = 15.sp,
                                                color = Color(0xFF1A1A2E),
                                                lineHeight = 26.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }

                        Button(
                            onClick = onNavigateToTechnicians,
                            colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("اعزام تکنسین")
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 4: STORE SCREEN ---
@Composable
fun StoreScreen(
    viewModel: AssistantViewModel,
    parts: List<KodyarSparePart>,
    cartItems: List<String>,
    onAddToCart: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Text(
            "فروشگاه قطعات یدکی",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = CodyarNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (parts.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 50.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("📦", fontSize = 36.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Text("فروشگاه در حال تکمیل است", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("به زودی قطعات اضافه می‌شوند", fontSize = 12.sp, color = Color.Gray)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(parts) { part ->
                    val inCart = cartItems.contains(part.id)
                    val outOfStock = (part.stock ?: 0) <= 0

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, Color(0xFFEAECEF))
                    ) {
                        Column {
                            // Product Image Block
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(Color(0xFFF7F8FA))
                                    .height(130.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                val finalImg = part.image ?: part.imageUrl ?: ""
                                if (finalImg.isNotEmpty()) {
                                    AsyncImage(
                                        model = if (finalImg.startsWith("http")) finalImg else "https://kodyar24.ir/${finalImg.removePrefix("/")}",
                                        contentDescription = part.name,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Text("⚙️", fontSize = 40.sp)
                                }
                            }

                            // Info block
                            Column(
                                modifier = Modifier.padding(11.dp),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Text(
                                    text = part.name ?: "",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1A1A2E),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    lineHeight = 18.sp
                                )
                                Text(
                                    text = part.brand ?: "",
                                    fontSize = 10.sp,
                                    color = Color(0xFF4A5568)
                                )

                                Text(
                                    text = if (outOfStock) "ناموجود" else "موجود (${part.stock})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (outOfStock) Color(0xFFC0392B) else Color(0xFF1E8449)
                                )

                                Text(
                                    text = "${formatToman(part.price ?: 0.0)} ت",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1E8449),
                                    modifier = Modifier.padding(vertical = 3.dp)
                                )

                                Button(
                                    onClick = { if (!outOfStock) onAddToCart(part.id ?: "") },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (inCart) Color(0xFFEAFAF1) else if (outOfStock) Color(0xFFF0F2F5) else Color(0xFF1E8449),
                                        contentColor = if (inCart) Color(0xFF1E8449) else if (outOfStock) Color(0xFF4A5568) else Color.White
                                    ),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("add_to_cart_button"),
                                    shape = RoundedCornerShape(7.dp),
                                    border = if (inCart) BorderStroke(1.dp, Color(0xFFA9DFBF)) else null,
                                    enabled = !outOfStock,
                                    contentPadding = PaddingValues(vertical = 7.dp)
                                ) {
                                    Text(
                                        text = if (inCart) "✓ اضافه شد" else if (outOfStock) "ناموجود" else "+ سبد خرید",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 5: TECHNICIANS LIST SCREEN ---
@Composable
fun TechniciansScreen(
    viewModel: AssistantViewModel,
    liveTechs: StateFlow<List<KodyarTechnician>>,
    currentUser: KodyarUser?,
    onShowAuth: () -> Unit
) {
    val context = LocalContext.current
    val techsList by liveTechs.collectAsState()
    val liveCities by viewModel.liveCities.collectAsState()
    var selectedCityFilter by remember { mutableStateOf("همه") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Text(
            "تکنسین‌های تایید شده",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = CodyarNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // City filters
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            liveCities.forEach { city ->
                val active = selectedCityFilter == city
                AssistChip(
                    onClick = { selectedCityFilter = city },
                    label = { Text(city, fontSize = 12.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = if (active) CodyarNavy else Color(0xFFF0F2F5),
                        labelColor = if (active) Color.White else Color(0xFF374151)
                    )
                )
            }
        }

        // List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(9.dp)
        ) {
            val filtered = techsList.filter { selectedCityFilter == "همه" || it.city == selectedCityFilter }

            items(filtered) { tech ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, Color(0xFFEAECEF))
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.spacedBy(11.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .background(CodyarNavy, RoundedCornerShape(11.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("👨‍🔧", fontSize = 20.sp)
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    tech.name ?: "",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1A1A2E)
                                )
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFEAFAF1), RoundedCornerShape(5.dp))
                                        .padding(horizontal = 7.dp, vertical = 2.dp)
                                ) {
                                    Text("✓ تایید شده", color = Color(0xFF1E8449), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }

                            Text(
                                "📍 ${tech.city ?: "نامشخص"} ${if ((tech.completedOrders ?: 0) > 0) " · ${tech.completedOrders} سرویس" else ""}",
                                fontSize = 11.sp,
                                color = Color(0xFF4A5568),
                                modifier = Modifier.padding(vertical = 4.dp)
                            )

                            if (!tech.bio.isNullOrBlank()) {
                                Text(
                                    tech.bio,
                                    fontSize = 11.sp,
                                    color = Color(0xFF374151),
                                    lineHeight = 16.sp,
                                    modifier = Modifier.padding(bottom = 7.dp)
                                )
                            }

                            // Categories
                            if (!tech.categories.isNullOrEmpty()) {
                                Row(
                                    modifier = Modifier
                                        .horizontalScroll(rememberScrollState())
                                        .padding(bottom = 9.dp),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    tech.categories.forEach { cat ->
                                        Box(
                                            modifier = Modifier
                                                .background(Color(0xFFE8EAF0), RoundedCornerShape(5.dp))
                                                .padding(horizontal = 7.dp, vertical = 2.dp)
                                        ) {
                                            Text(cat, color = Color(0xFF374151), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Button(
                                onClick = {
                                    if (currentUser == null) {
                                        onShowAuth()
                                        return@Button
                                    }
                                    viewModel.submitRepairRequest(
                                        techId = tech.id ?: "",
                                        description = "درخواست تعمیرکار در اپلیکیشن",
                                        city = tech.city ?: ""
                                    ) { success, err ->
                                        if (success) {
                                            Toast.makeText(
                                                context,
                                                "✅ درخواست شما ثبت شد. تکنسین با شما تماس می‌گیرد.",
                                                Toast.LENGTH_LONG
                                            ).show()
                                        } else {
                                            Toast.makeText(context, err ?: "خطا", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(vertical = 8.dp)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(13.dp))
                                Spacer(modifier = Modifier.width(5.dp))
                                Text("اعزام تکنسین", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            if (filtered.isEmpty()) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 50.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text("تکنسینی ثبت نشده است", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("به زودی تکنسین‌های تایید شده اضافه می‌شوند", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }

            // Bottom CTA for techs
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 14.dp),
                    colors = CardDefaults.cardColors(containerColor = CodyarNavy),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("تکنسین هستید؟", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                        Text(
                            "با همکاران ما در وب‌سایت کدیار تماس بگیرید و پس از تایید مدارک سفارش کار دریافت کنید.",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.6f),
                            textAlign = TextAlign.Center,
                            lineHeight = 18.sp
                        )
                        Button(
                            onClick = {
                                // Normally opens URL
                                Toast.makeText(context, "وب‌سایت کدیار۲۴ باز می‌شود (Kodyar24.ir)", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CodyarRed),
                            shape = RoundedCornerShape(9.dp)
                        ) {
                            Text("ثبت‌نام تکنسین در سایت", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 6: PROFILE SCREEN ---
@Composable
fun ProfileScreen(
    viewModel: AssistantViewModel,
    currentUser: KodyarUser?,
    onShowAuth: () -> Unit,
    onShowPlans: () -> Unit,
    onNavigateToOrders: () -> Unit,
    onNavigateToSaved: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        if (currentUser == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 60.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("👤", fontSize = 44.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Text("وارد حساب خود شوید", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1A1A2E))
                Text("جهت دسترسی به اشتراک ویژه و مدیریت درخواست‌های خود", fontSize = 13.sp, color = Color(0xFF4A5568), modifier = Modifier.padding(vertical = 6.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onShowAuth,
                    colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(5.dp))
                    Text("ورود / ثبت‌نام")
                }
            }
        } else {
            val isPremium = currentUser.subscription?.is_premium == true
            val expiry = currentUser.subscription?.expiry_date?.take(10) ?: ""

            // Main User details card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .background(CodyarNavy, RoundedCornerShape(12.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                        }
                        Column {
                            Text(currentUser.full_name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF1A1A2E))
                            Text(currentUser.phone, fontSize = 12.sp, color = Color(0xFF4A5568), modifier = Modifier.padding(top = 2.dp))
                        }
                    }

                    if (isPremium) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF9E7)),
                            border = BorderStroke(1.dp, Color(0xFFFDE68A)),
                            shape = RoundedCornerShape(9.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFC9A227))
                                Column {
                                    Text("اشتراک ویژه شما فعال است", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF92400E))
                                    if (expiry.isNotEmpty()) {
                                        Text("انقضا تا تاریخ: $expiry", fontSize = 10.sp, color = Color(0xFF92400E))
                                    }
                                }
                            }
                        }
                    } else {
                        Button(
                            onClick = onShowPlans,
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC9A227)),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(5.dp))
                            Text("ارتقا به اشتراک ویژه")
                        }
                    }
                }
            }

            // Menu choices
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val menuItems = listOf(
                        QuadProfileMenu(Icons.Default.Star, Color(0xFFC9A227), "اشتراک و پلن‌ها", onShowPlans),
                        QuadProfileMenu(Icons.Default.Build, Color(0xFF1E8449), "سفارشات تعمیر من", onNavigateToOrders),
                        QuadProfileMenu(Icons.Default.Favorite, Color(0xFF2563EB), "کدهای ذخیره شده", onNavigateToSaved),
                        QuadProfileMenu(Icons.Default.ExitToApp, Color(0xFFC0392B), "خروج از حساب کاربری", { viewModel.logout() })
                    )

                    menuItems.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { item.action() }
                                .padding(horizontal = 14.dp, vertical = 13.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .background(item.tint.copy(alpha = 0.1f), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(item.icon, contentDescription = item.label, tint = item.tint, modifier = Modifier.size(15.dp))
                            }
                            Text(
                                text = item.label,
                                modifier = Modifier.weight(1f),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF1A1A2E)
                            )
                            Icon(Icons.Default.KeyboardArrowLeft, contentDescription = null, tint = Color(0xFFD1D5DB))
                        }

                        if (index < menuItems.size - 1) {
                            HorizontalDivider(color = Color(0xFFF7F8FA))
                        }
                    }
                }
            }
        }
    }
}

data class QuadProfileMenu(
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val tint: Color,
    val label: String,
    val action: () -> Unit
)

// --- TAB 7: REPAIR ORDERS SCREEN ---
@Composable
fun OrdersScreen(
    viewModel: AssistantViewModel,
    repairOrders: List<KodyarRepairOrder>,
    isRepairsLoading: Boolean,
    onBack: () -> Unit,
    onNavigateToTechs: () -> Unit
) {
    val statusMap = mapOf(
        "pending" to Triple("در انتظار", Color(0xFFD68910), Color(0xFFFEF9E7)),
        "accepted" to Triple("تایید شده", Color(0xFF1E8449), Color(0xFFEAFAF1)),
        "ongoing" to Triple("در حال انجام", Color(0xFF2563EB), Color(0xFFEFF6FF)),
        "completed" to Triple("تکمیل شده", Color(0xFF374151), Color(0xFFF0F2F5)),
        "rejected" to Triple("لغو شده", Color(0xFFC0392B), Color(0xFFFDF0EE))
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp)
    ) {
        Button(
            onClick = onBack,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.White,
                contentColor = Color(0xFF374151)
            ),
            border = BorderStroke(1.dp, Color(0xFFEAECEF)),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(horizontal = 11.dp, vertical = 7.dp),
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(5.dp)
            ) {
                Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(14.dp))
                Text("بازگشت", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Text(
            "سفارشات تعمیر من",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = CodyarNavy,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        if (isRepairsLoading) {
            Box(modifier = Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = CodyarNavy)
            }
        } else if (repairOrders.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 50.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text("🔧", fontSize = 44.sp)
                Spacer(modifier = Modifier.height(10.dp))
                Text("سفارشی ثبت نشده است", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF374151))
                Text("جهت ثبت درخواست با تکنسین تماس حاصل فرمایید", fontSize = 13.sp, color = Color.Gray, modifier = Modifier.padding(bottom = 20.dp))
                Button(
                    onClick = onNavigateToTechs,
                    colors = ButtonDefaults.buttonColors(containerColor = CodyarNavy)
                ) {
                    Text("لیست تکنسین‌ها")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(repairOrders.size) { i ->
                    val o = repairOrders[i]
                    val sKey = o.status ?: "pending"
                    val (label, textCol, bgCol) = statusMap[sKey] ?: Triple("در انتظار", Color(0xFFD68910), Color(0xFFFEF9E7))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, Color(0xFFEAECEF)),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "درخواست تعمیر #${i + 1}",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFF1A1A2E)
                                )
                                Box(
                                    modifier = Modifier
                                        .background(bgCol, RoundedCornerShape(7.dp))
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = label,
                                        color = textCol,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            if (!o.description.isNullOrBlank()) {
                                Text(
                                    text = o.description,
                                    fontSize = 13.sp,
                                    color = Color(0xFF374151),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                        .background(Color(0xFFF7F8FA), RoundedCornerShape(8.dp))
                                        .padding(10.dp)
                                )
                            }

                            if (!o.city.isNullOrBlank()) {
                                Text(
                                    text = "📍 شهر: ${o.city}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF4A5568),
                                    modifier = Modifier.padding(bottom = 6.dp)
                                )
                            }

                            if (!o.technician_name.isNullOrBlank()) {
                                Text(
                                    text = "👨‍🔧 تکنسین: ${o.technician_name}",
                                    fontSize = 12.sp,
                                    color = Color(0xFF4A5568),
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (!o.created_at.isNullOrBlank()) {
                                val cleanDate = o.created_at.take(10)
                                Text(
                                    text = "تاریخ ثبت: $cleanDate",
                                    fontSize = 11.sp,
                                    color = Color(0xFF9AA3AF),
                                    modifier = Modifier.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- TAB 8: AI ASSISTANT CHAT SCREEN (SUPPLEMENTARY) ---
@Composable
fun AiChatScreen(viewModel: AssistantViewModel) {
    // Supplementary Composable if AI tab is enabled or called
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("دستیار هوشمند تعمیرات کدیار۲۴")
    }
}
