package com.example.ui

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.AssistantRepository
import com.example.data.db.ConversationEntity
import com.example.data.db.MessageEntity
import com.example.data.db.SavedErrorEntity
import com.example.data.db.CustomErrorEntity
import com.example.data.model.*
import com.example.data.repository.ErrorCodeRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AssistantViewModel(
    private val repository: AssistantRepository,
    context: Context
) : ViewModel() {

    private val sharedPrefs: SharedPreferences = context.getSharedPreferences("kodyar_prefs", Context.MODE_PRIVATE)

    // --- Database states ---
    private val _liveErrorCodes = MutableStateFlow<List<KodyarErrorCode>>(emptyList())
    val liveErrorCodes: StateFlow<List<KodyarErrorCode>> = _liveErrorCodes.asStateFlow()

    private val _liveSpareParts = MutableStateFlow<List<KodyarSparePart>>(emptyList())
    val liveSpareParts: StateFlow<List<KodyarSparePart>> = _liveSpareParts.asStateFlow()

    private val _liveTechnicians = MutableStateFlow<List<KodyarTechnician>>(emptyList())
    val liveTechnicians: StateFlow<List<KodyarTechnician>> = _liveTechnicians.asStateFlow()

    private val _liveCommonProblems = MutableStateFlow<List<KodyarCommonProblem>>(emptyList())
    val liveCommonProblems: StateFlow<List<KodyarCommonProblem>> = _liveCommonProblems.asStateFlow()

    private val _liveCategories = MutableStateFlow<List<String>>(listOf("همه"))
    val liveCategories: StateFlow<List<String>> = _liveCategories.asStateFlow()

    private val _liveBrands = MutableStateFlow<List<String>>(listOf("همه"))
    val liveBrands: StateFlow<List<String>> = _liveBrands.asStateFlow()

    private val _liveCities = MutableStateFlow<List<String>>(listOf("همه"))
    val liveCities: StateFlow<List<String>> = _liveCities.asStateFlow()

    private val _isDatabaseLoading = MutableStateFlow(false)
    val isDatabaseLoading: StateFlow<Boolean> = _isDatabaseLoading.asStateFlow()

    // --- Search states ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedBrand = MutableStateFlow("همه")
    val selectedBrand: StateFlow<String> = _selectedBrand.asStateFlow()

    private val _selectedCategory = MutableStateFlow("همه")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _searchResults = MutableStateFlow<List<KodyarErrorCode>>(emptyList())
    val searchResults: StateFlow<List<KodyarErrorCode>> = _searchResults.asStateFlow()

    // --- Auth states ---
    private val _currentUser = MutableStateFlow<KodyarUser?>(null)
    val currentUser: StateFlow<KodyarUser?> = _currentUser.asStateFlow()

    private val _isAuthLoading = MutableStateFlow(false)
    val isAuthLoading: StateFlow<Boolean> = _isAuthLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    // --- Cart states ---
    private val _cart = MutableStateFlow<List<String>>(emptyList())
    val cart: StateFlow<List<String>> = _cart.asStateFlow()

    private val _cartQty = MutableStateFlow<Map<String, Int>>(emptyMap())
    val cartQty: StateFlow<Map<String, Int>> = _cartQty.asStateFlow()

    private val _isPurchaseLoading = MutableStateFlow(false)
    val isPurchaseLoading: StateFlow<Boolean> = _isPurchaseLoading.asStateFlow()

    private val _purchaseSuccess = MutableStateFlow(false)
    val purchaseSuccess: StateFlow<Boolean> = _purchaseSuccess.asStateFlow()

    // --- Repair state ---
    private val _repairOrders = MutableStateFlow<List<KodyarRepairOrder>>(emptyList())
    val repairOrders: StateFlow<List<KodyarRepairOrder>> = _repairOrders.asStateFlow()

    private val _isRepairsLoading = MutableStateFlow(false)
    val isRepairsLoading: StateFlow<Boolean> = _isRepairsLoading.asStateFlow()

    // --- Sub / Verification state ---
    private val _isCardVerifyLoading = MutableStateFlow(false)
    val isCardVerifyLoading: StateFlow<Boolean> = _isCardVerifyLoading.asStateFlow()

    private val _cardVerifySuccess = MutableStateFlow(false)
    val cardVerifySuccess: StateFlow<Boolean> = _cardVerifySuccess.asStateFlow()

    // --- Usage counts ---
    private val _freeErrorCount = MutableStateFlow(0)
    val freeErrorCount: StateFlow<Int> = _freeErrorCount.asStateFlow()

    private val _freeProblemCount = MutableStateFlow(0)
    val freeProblemCount: StateFlow<Int> = _freeProblemCount.asStateFlow()

    init {
        loadKodyarDatabase()
        checkSavedSession()
    }

    // --- Session & Auth functions ---
    private fun getSessionToken(): String? {
        return sharedPrefs.getString("session_token", null)
    }

    private fun checkSavedSession() {
        val token = getSessionToken()
        if (token != null) {
            loadCurrentUser(token)
        }
    }

    fun loadCurrentUser(token: String) {
        viewModelScope.launch {
            try {
                val response = repository.getMe(token)
                if (response.status == "ok" && response.user != null) {
                    _currentUser.value = response.user
                    loadFreeStatus()
                    loadRepairs()
                } else {
                    // Token might be invalid
                    logout()
                }
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error fetching user", e)
            }
        }
    }

    fun login(phone: String, pass: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            try {
                val response = repository.login(phone, pass)
                if (response.status == "ok" && response.user != null) {
                    _currentUser.value = response.user
                    sharedPrefs.edit().putString("session_token", response.user.id).apply()
                    loadFreeStatus()
                    loadRepairs()
                    onResult(true, null)
                } else {
                    _authError.value = response.error ?: "خطا در ورود"
                    onResult(false, _authError.value)
                }
            } catch (e: Exception) {
                _authError.value = "خطای اتصال به سرور: ${e.message}"
                onResult(false, _authError.value)
            } finally {
                _isAuthLoading.value = false
            }
        }
    }

    fun register(
        phone: String,
        pass: String,
        name: String,
        role: String = "customer",
        city: String? = null,
        categories: List<String>? = null,
        onResult: (Boolean, String?) -> Unit
    ) {
        viewModelScope.launch {
            _isAuthLoading.value = true
            _authError.value = null
            try {
                val response = repository.register(phone, pass, name)
                if (response.status == "ok" && response.user != null) {
                    val finalUser = if (role == "technician") {
                        response.user.copy(role = "technician", city = city, categories = categories)
                    } else {
                        response.user.copy(role = "customer")
                    }
                    _currentUser.value = finalUser
                    sharedPrefs.edit().putString("session_token", response.user.id).apply()
                    
                    if (role == "technician") {
                        val newTech = KodyarTechnician(
                            id = finalUser.id,
                            name = finalUser.full_name,
                            city = city ?: "تهران",
                            isVerified = true,
                            completedOrders = 0,
                            bio = "تکنسین متخصص لوازم خانگی کدیار۲۴",
                            categories = categories ?: listOf("ماشین لباسشویی", "یخچال و فریزر")
                        )
                        _liveTechnicians.value = _liveTechnicians.value + newTech
                    }
                    
                    loadFreeStatus()
                    loadRepairs()
                    onResult(true, null)
                } else {
                    _authError.value = response.error ?: "خطا در ثبت‌نام"
                    onResult(false, _authError.value)
                }
            } catch (e: Exception) {
                _authError.value = "خطای اتصال به سرور: ${e.message}"
                onResult(false, _authError.value)
            } finally {
                _isAuthLoading.value = false
            }
        }
    }

    fun logout() {
        _currentUser.value = null
        sharedPrefs.edit().remove("session_token").apply()
        _repairOrders.value = emptyList()
        _freeErrorCount.value = 0
        _freeProblemCount.value = 0
    }

    // --- Load Kodyar Database ---
    fun loadKodyarDatabase() {
        viewModelScope.launch {
            _isDatabaseLoading.value = true
            try {
                val response = repository.getKodyarDatabase()
                _liveErrorCodes.value = response.errorCodes ?: emptyList()
                _liveSpareParts.value = response.spareParts ?: emptyList()
                _liveTechnicians.value = response.technicians ?: emptyList()
                _liveCommonProblems.value = response.commonProblems ?: emptyList()

                _liveCategories.value = listOf("همه") + (response.categoriesList ?: emptyList())
                _liveBrands.value = listOf("همه") + (response.brandsList ?: emptyList())
                val parsedCities = response.citiesList?.mapNotNull { 
                    it.name ?: it.title ?: it.city ?: it.cityName ?: it.name_fa ?: it.nameFarsi ?: it.slug
                } ?: emptyList()
                _liveCities.value = listOf("همه") + parsedCities

                // Trigger initial search results
                updateSearchFilters(_searchQuery.value, _selectedBrand.value, _selectedCategory.value)
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error loading kodyar database. Using fallback.", e)
                // Fallback to static error codes if network is unavailable
                val fallbackList = ErrorCodeRepository.staticErrorCodes.map {
                    KodyarErrorCode(
                        id = it.code,
                        code = it.code,
                        brand = it.brand,
                        category = it.category,
                        title = it.code,
                        description = it.description,
                        causes = emptyList<String>(),
                        steps = listOf(it.solution),
                        hazardLevel = when(it.severity) {
                            "بحرانی" -> "high"
                            "متوسط" -> "medium"
                            else -> "low"
                        },
                        videoUrl = null,
                        isApproved = true
                    )
                }
                _liveErrorCodes.value = fallbackList
                _liveCategories.value = ErrorCodeRepository.categories.map { if (it == "همه دستگاه‌ها") "همه" else it }
                _liveBrands.value = ErrorCodeRepository.brands.map { if (it == "همه برندها") "همه" else it }
                
                updateSearchFilters(_searchQuery.value, _selectedBrand.value, _selectedCategory.value)
            } finally {
                _isDatabaseLoading.value = false
            }
        }
    }

    fun updateSearchFilters(query: String, brand: String, category: String) {
        _searchQuery.value = query
        _selectedBrand.value = brand
        _selectedCategory.value = category

        _searchResults.value = _liveErrorCodes.value.filter { error ->
            val matchQuery = query.isEmpty() ||
                    (error.code ?: "").contains(query, ignoreCase = true) ||
                    (error.brand ?: "").contains(query, ignoreCase = true) ||
                    (error.category ?: "").contains(query, ignoreCase = true) ||
                    (error.title ?: "").contains(query, ignoreCase = true) ||
                    (error.description ?: "").contains(query, ignoreCase = true)

            val matchBrand = brand == "همه" || error.brand == brand
            val matchCategory = category == "همه" || error.category == category

            matchQuery && matchBrand && matchCategory
        }
    }

    // --- Shorthand Helper to parse Causes / Steps ---
    fun Any?.toListOfStrings(): List<String> {
        if (this == null) return emptyList()
        if (this is List<*>) {
            return this.mapNotNull { it?.toString()?.trim() }.filter { it.isNotEmpty() }
        }
        val str = this.toString().trim()
        if (str.isEmpty()) return emptyList()
        return str.split(Regex("[\r\n؛•\\n]+")).map { it.trim() }.filter { it.isNotEmpty() }
    }

    // --- Bookmarked / Saved Errors ---
    val savedErrors: StateFlow<List<SavedErrorEntity>> = repository.allSavedErrors
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun toggleSavedError(code: String, brand: String, category: String, isCurrentlySaved: Boolean) {
        viewModelScope.launch {
            repository.toggleSavedError(code, brand, category, isCurrentlySaved)
        }
    }

    fun isErrorSaved(code: String, brand: String, category: String): Flow<Boolean> {
        return repository.isErrorSaved(code, brand, category)
    }

    // --- Custom / Notes Errors ---
    val customErrors: StateFlow<List<CustomErrorEntity>> = repository.allCustomErrors
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addCustomError(code: String, brand: String, category: String, description: String, solution: String, severity: String, userNote: String) {
        viewModelScope.launch {
            val custom = CustomErrorEntity(
                code = code,
                brand = brand,
                category = category,
                description = description,
                solution = solution,
                severity = severity,
                userNote = userNote
            )
            repository.addCustomError(custom)
        }
    }

    fun deleteCustomError(id: Long) {
        viewModelScope.launch {
            repository.deleteCustomError(id)
        }
    }

    fun updateCustomErrorNote(id: Long, note: String) {
        viewModelScope.launch {
            repository.updateCustomErrorNote(id, note)
        }
    }

    // --- Cart functions ---
    fun addToCart(partId: String) {
        val currentCart = _cart.value.toMutableList()
        if (!currentCart.contains(partId)) {
            currentCart.add(partId)
            _cart.value = currentCart
        }
        val currentQty = _cartQty.value.toMutableMap()
        currentQty[partId] = currentQty[partId] ?: 1
        _cartQty.value = currentQty
    }

    fun removeFromCart(partId: String) {
        val currentCart = _cart.value.toMutableList()
        currentCart.remove(partId)
        _cart.value = currentCart

        val currentQty = _cartQty.value.toMutableMap()
        currentQty.remove(partId)
        _cartQty.value = currentQty
    }

    fun updateCartQty(partId: String, qty: Int) {
        val currentQty = _cartQty.value.toMutableMap()
        if (qty > 0) {
            currentQty[partId] = qty
            _cartQty.value = currentQty
        }
    }

    fun clearCart() {
        _cart.value = emptyList()
        _cartQty.value = emptyMap()
        _purchaseSuccess.value = false
    }

    fun submitPurchase(address: String, notes: String, cardHolder: String, trackNumber: String, onResult: (Boolean, String?) -> Unit) {
        val token = getSessionToken()
        if (token == null) {
            onResult(false, "باید وارد حساب خود شوید")
            return
        }

        viewModelScope.launch {
            _isPurchaseLoading.value = true
            try {
                // We'll iterate and call API for each item as done in HTML
                for (partId in _cart.value) {
                    val part = _liveSpareParts.value.find { it.id == partId } ?: continue
                    val qty = _cartQty.value[partId] ?: 1
                    val price = part.price ?: 0.0
                    val subtotal = price * qty

                    val response = repository.purchasePart(
                        token = token,
                        partId = partId,
                        partName = part.name ?: "",
                        qty = qty,
                        price = price,
                        total = subtotal,
                        address = address,
                        notes = notes,
                        cardHolder = cardHolder,
                        track = trackNumber
                    )

                    if (response.status != "ok") {
                        onResult(false, response.error ?: "خطا در ثبت فیش برای قطعه ${part.name}")
                        _isPurchaseLoading.value = false
                        return@launch
                    }
                }
                _purchaseSuccess.value = true
                _cart.value = emptyList()
                _cartQty.value = emptyMap()
                onResult(true, null)
            } catch (e: Exception) {
                onResult(false, "خطای اتصال به شبکه: ${e.message}")
            } finally {
                _isPurchaseLoading.value = false
            }
        }
    }

    // --- Repair Orders ---
    fun loadRepairs() {
        val token = getSessionToken() ?: return
        viewModelScope.launch {
            _isRepairsLoading.value = true
            try {
                val response = repository.getRepairs(token)
                _repairOrders.value = response.repairs ?: response.data ?: emptyList()
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error fetching repairs", e)
            } finally {
                _isRepairsLoading.value = false
            }
        }
    }

    fun submitRepairRequest(techId: String, description: String, city: String, onResult: (Boolean, String?) -> Unit) {
        val token = getSessionToken()
        if (token == null) {
            onResult(false, "باید وارد حساب خود شوید")
            return
        }

        viewModelScope.launch {
            try {
                val response = repository.createRepair(token, techId, description, city)
                if (response.status == "ok") {
                    loadRepairs()
                    onResult(true, null)
                } else {
                    onResult(false, response.error ?: "خطا در ثبت درخواست تعمیرکار")
                }
            } catch (e: Exception) {
                onResult(false, "خطای ارتباط به سرور: ${e.message}")
            }
        }
    }

    // --- Subscription Card Verification ---
    fun submitCardVerify(cardHolder: String, trackNumber: String, productId: String, onResult: (Boolean, String?) -> Unit) {
        val token = getSessionToken()
        if (token == null) {
            onResult(false, "باید وارد حساب خود شوید")
            return
        }

        viewModelScope.launch {
            _isCardVerifyLoading.value = true
            try {
                val response = repository.verifyCard(token, cardHolder, trackNumber, productId)
                if (response.status == "ok") {
                    _cardVerifySuccess.value = true
                    checkSavedSession() // Refreshes premium status
                    onResult(true, null)
                } else {
                    onResult(false, response.error ?: "خطا در ثبت فیش پرداخت")
                }
            } catch (e: Exception) {
                onResult(false, "خطای ارتباط به سرور: ${e.message}")
            } finally {
                _isCardVerifyLoading.value = false
            }
        }
    }

    fun resetCardVerifySuccess() {
        _cardVerifySuccess.value = false
    }

    // --- Free usages ---
    fun loadFreeStatus() {
        val token = getSessionToken() ?: return
        viewModelScope.launch {
            try {
                val response = repository.getFreeStatus(token)
                _freeErrorCount.value = response.error_count ?: 0
                _freeProblemCount.value = response.problem_count ?: 0
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error loading free status", e)
            }
        }
    }

    fun useFreeCount(type: String, onComplete: () -> Unit) {
        val token = getSessionToken()
        if (token == null) {
            onComplete()
            return
        }
        viewModelScope.launch {
            try {
                val response = repository.useFree(token, type)
                _freeErrorCount.value = response.error_count ?: _freeErrorCount.value
                _freeProblemCount.value = response.problem_count ?: _freeProblemCount.value
            } catch (e: Exception) {
                Log.e("AssistantViewModel", "Error posting free use", e)
            } finally {
                onComplete()
            }
        }
    }

    // --- AI Smart Repair Assistant Conversation State ---
    val conversations: StateFlow<List<ConversationEntity>> = repository.allConversations
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    private val _currentConversationId = MutableStateFlow<Long?>(null)
    val currentConversationId: StateFlow<Long?> = _currentConversationId.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    @OptIn(ExperimentalCoroutinesApi::class)
    val currentMessages: StateFlow<List<MessageEntity>> = _currentConversationId
        .flatMapLatest { id ->
            if (id != null) {
                repository.getMessages(id)
            } else {
                flowOf(emptyList())
            }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Dedicated System Instruction for Home Appliance Repair Expert AI
    private val repairAssistantSystemInstruction = """
        شما یک تعمیرکار فوق‌العاده با‌تجربه، دقیق، دلسوز و حرفه‌ای لوازم خانگی به نام کدیار۲۴ (Codyar24) هستید. 
        شما باید به زبان فارسی صمیمی، روان، مودبانه و بسیار فنی، کاربران و تعمیرکاران را برای عیب‌یابی و حل مشکلات لوازم خانگی مانند ماشین لباسشویی، یخچال، فریزر، ماشین ظرفشویی، کولر گازی، اسپلیت، جاروبرقی، مایکروویو و سایر تجهیزات هدایت کنید.
        
        لطفاً هنگام پاسخ دادن به هر سوال عیب‌یابی:
        1. علت‌های احتمالی (مثلاً خرابی قطعه، اتصالات، کثیفی فیلترها و غیره) را به صورت لیست‌وار و خوانا بنویسید.
        2. مراحل گام‌به‌گام برای تست و رفع عیب ارائه دهید.
        3. نکات ایمنی (مانند کشیدن دوشاخه از برق قبل از هر تستی) را حتماً متذکر شوید.
        4. در صورت نیاز به بررسی تخصصی‌تر، بگویید که نیاز به تکنسین مجاز است.
        پاسخ‌های شما باید کاملاً متمرکز بر حل مشکل و کاربردی باشند.
    """.trimIndent()

    fun selectConversation(id: Long?) {
        _currentConversationId.value = id
        _errorMessage.value = null
    }

    fun startNewConversation() {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                val conversationId = repository.createConversation("گفتگوی جدید تعمیراتی", "Codyar24")
                _currentConversationId.value = conversationId
                
                // Seed custom welcoming message in Persian
                val welcome = MessageEntity(
                    conversationId = conversationId,
                    role = "model",
                    text = "سلام! من کدیار۲۴ دستیار هوشمند و تخصصی تعمیرات لوازم خانگی شما هستم. دستگاه شما چه مشکلی دارد؟ یا به دنبال کدام کد خطا هستید؟ برند و مشکل آن را مطرح کنید تا با هم عیب‌یابی کنیم."
                )
                // Use sendMessage or a custom direct insertion
            } catch (e: Exception) {
                _errorMessage.value = "خطا در شروع گفتگو: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun deleteConversation(id: Long) {
        viewModelScope.launch {
            if (_currentConversationId.value == id) {
                _currentConversationId.value = null
            }
            repository.deleteConversation(id)
        }
    }

    fun clearAllConversations() {
        viewModelScope.launch {
            _currentConversationId.value = null
            repository.clearAllConversations()
        }
    }

    fun sendMessage(text: String) {
        val trimmedText = text.trim()
        if (trimmedText.isEmpty()) return

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null
            try {
                var convId = _currentConversationId.value

                // If no active conversation, create one dynamically
                if (convId == null) {
                    val generatedTitle = if (trimmedText.length > 25) {
                        "${trimmedText.take(22)}..."
                    } else {
                        trimmedText
                    }
                    convId = repository.createConversation(generatedTitle, "Codyar24")
                    _currentConversationId.value = convId
                }

                if (convId != null) {
                    val result = repository.sendMessage(
                        conversationId = convId,
                        userText = trimmedText,
                        systemInstructionText = repairAssistantSystemInstruction
                    )
                    
                    result.onFailure { exception ->
                        _errorMessage.value = exception.localizedMessage ?: "خطای ارتباط با سرور هوش مصنوعی"
                    }
                }
            } catch (e: Exception) {
                _errorMessage.value = "خطا در ارسال پیام: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }
}

class AssistantViewModelFactory(
    private val repository: AssistantRepository,
    private val context: Context
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AssistantViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AssistantViewModel(repository, context) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
